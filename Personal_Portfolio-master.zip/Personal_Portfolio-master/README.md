# Personal_Portfolio
My personal portfolio designed as a Internship Project for CodSoft 
created by using HTML CSS JavaScript  on VS CODE 
Feel free to contact @ farhan1900182@st.jmi.ac.in
ABOVE CODE CAN BE USED BY THE CODSOFT INFOTECH ONLY . 